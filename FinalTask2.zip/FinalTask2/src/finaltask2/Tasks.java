/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finaltask2;

import javax.swing.JOptionPane;

/**
 *
 * @author preshay
 */
public class Tasks {
    
    boolean checkTaskDescription;
    String createTaskID;
    String printTaskDetails;
    int returnTotalHours;
    
    //method 1
    public boolean ischeckTaskDescription(String taskName)
    {
      if(taskName.length() <=50)  
      {
          JOptionPane.showMessageDialog(null,"Task captured");
          
      }
      else
      {
         JOptionPane.showMessageDialog(null,"Desc exceeded ..."); 
      }
      return checkTaskDescription = true;
    }
    public void setCheckTaskDescription(boolean  checkTaskDescription){
        this.checkTaskDescription = checkTaskDescription;
    }
    
    
    public String getCreateTaskID(String taskName, String taskDev, String taskID, int taskNumber)
    {
       taskID = taskName.substring(0,2).toUpperCase()+ ":" 
               + taskNumber + ":" 
               + taskDev.substring(taskDev.length() -3).toUpperCase ();
        
       return taskID;        
    }
    //the setter
    public void setCreateTaskID(String createTaskID) {
        this.createTaskID = createTaskID;
    }
    
    public String getPrintTaskDetails(String taskStatus, String taskDevDetails,int taskNumber, String taskName, String taskDescription, String taskID, int taskDuration)
    {
        JOptionPane.showMessageDialog(null,"Task details of task : "
                +"\nTask Stats: "+taskStatus
                +"\nDeveloper Details: "+ taskDevDetails
                + taskNumber
                +"\nTask Name: "+taskName
                +"\nTask Description: "+ taskDescription
                +"\nTask ID: " + taskID
                +"\nTask Duration: "+ taskDuration +" hours");
        return printTaskDetails;
                
    }
    
     public void setPrintTaskDetails (String printTaskDetails) {
         this.printTaskDetails = printTaskDetails;
     }
     
     
     public int getreturnTotalHours(int taskDuration, int totalHours){
         //calculate total hours
         totalHours = totalHours+taskDuration;
         return returnTotalHours;
     }
     
      public void setReturnTotalHours(int returnTotalHours) {
          this.returnTotalHours = returnTotalHours;
      }
}

