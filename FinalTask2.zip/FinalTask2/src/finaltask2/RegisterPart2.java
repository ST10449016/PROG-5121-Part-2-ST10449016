/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finaltask2;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author preshay
 */
public class RegisterPart2 {
        //make global variables
    public static String registeredUsername;
    public static String registeredPassword;
    public static String regname;
    public static String regsurname;
    
    //make check username method
    public static void RegisterUser(){//method starts here
        //ask user to register and login before using the program
        JOptionPane.showMessageDialog(null,"Please complete the following steps before continuing"
                + "\n [1] Register"
                + "\n [2] Login");
        
        //check username 
        //make variables for check username
        boolean checkUsername = false;
        String username;
        
        //make a do to check username
        do{
            username = JOptionPane.showInputDialog(null,"Please create a username >>"
            + "\nusername must contain '_' and must be "
            + "be a least 5 characters in length");
            
            //make a if 
            if (!checkUsername){
            System.out.println("Username is not correctly formatted! \n");
        }//if ends here
            else{
                System.out.println("Username successfully captured! \n");
            }    
            
            
            
        }while (!checkUsername);
        
        //check password
        //mke variables for check password complexity
        boolean checkPasswordComplexity = false;
        String userPassword;
        
        //make a do to check password
        do{//do starts here
            //ask user to create a password and store it in the userPassword variable
            userPassword=(JOptionPane.showInputDialog(null,"Please create a apassowrd >>"
                + "\nPlease ensure your pssword contains: \n"    
                + "1 Upper case \n"
                + "1 Number \n"
                + "1 Special character [@#$!] \n"
                + "and be a min of 8 chars in length"));
            //check if password  meets requirements
            Pattern specialPattern = Pattern.compile(" (^A - Z  a - z  0 - 9) ");
        Pattern digitPattern = Pattern.compile("\\d");
        Pattern capsPattern = Pattern.compile("(A - Z) ");
        
        Matcher specialMatcher = specialPattern.matcher (userPassword);
        Matcher digitMatcher = digitPattern.matcher(userPassword);
        Matcher capsMatcher = capsPattern.matcher(userPassword);
        
        
        //if statement to check password
        checkPasswordComplexity = (userPassword.length()>=8) && specialMatcher.find()
        && digitMatcher.find()
        && capsMatcher.find();
        
        
        
        if (!checkPasswordComplexity){
            System.out.println("Password is not correctly formatted!");  
        }//if ends 
        else{
            System.out.println("Password successfully captured!");
        }while (!checkPasswordComplexity);
        
        //confirm registration
        //variables
        String name;
        String surname;
        
        //tell the user to enter their details
        name = JOptionPane.showInputDialog(null,"Please enter your name");
        //name = input.nextLine();
        surname = JOptionPane.showInputDialog(null,"Please enter your surname");
        //surname = input.nextLine();
        
        regname= name;
        regsurname = surname;
        registeredUsername= username;
        registeredPassword = userPassword;
        JOptionPane.showMessageDialog(null,"\nCongratulations! Registration is now complete! \n ");
         }while(!checkPasswordComplexity);
      
        
        }//method ends here
}       
   

