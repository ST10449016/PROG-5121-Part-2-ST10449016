/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finaltask2;

import javax.swing.JOptionPane;

/**
 *
 * @author preshay
 */
public class FinalTask2 {

  public static int arraySize;
 
    public static void main(String[] args) {
        // make a message to welcome user to program
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
        //call methods
        classesMethod();
        mainMenu();
        
    }
    
    
    //create main method to link login and register classes to
       public static void classesMethod()
       {//method starts here
           
           //create scanners to call classes
           LoginPart2 login = new LoginPart2();
           RegisterPart2 register = new RegisterPart2();
           
           //call classes
           //MUST put register class before login 
           register.RegisterUser();
           login.loginUser();
           
       
        }   //method ends here
       
       
       //make another method for user input for the EasyKanban program
       public static void mainMenu(){ //method starts here
           //obtain variables and set boolean value to false
           boolean closeProgram = false;
           int menuChoice;
           
           //make a while loop
           while(!closeProgram ){//while loop starts here
               //ask the user to pick an option to continue 
               menuChoice = Integer.parseInt(JOptionPane.showInputDialog(null,">> Welcome to EasyKanban <<"
                       + "\nPlease choose an option to continue..."
                       + "\n[1] - Add Tasks"
                       + "\n[2] - Show Report"
                       + "\n[3] - Exit Program"));
               
               //create a switch
               switch(menuChoice){//switch starts here
                   case 1: tasks();break;
                   case 2: JOptionPane.showMessageDialog(null,"Coming soon");break;
                   case 3: JOptionPane.showMessageDialog(null,"Exiting the program..." );closeProgram = true;break;
                   default: JOptionPane.showMessageDialog(null,"Please eneter a valid option");break;
               }//switch ends here
           }//while ends here
       }//method ends here
        
                   
                   
        //method to add array
                   static void tasks(){
                   //ask the user how many values will be added to the array
                   arraySize = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter number of values >>"));
                   //check if number of values are valid
                   if (arraySize <=0) {
                       JOptionPane.showMessageDialog(null,"Please eneter a valid number");
                   }//if ends here
                   
                   //create arrays
                   String [] taskName = new String [arraySize];
                   String[] taskDescription = new String [arraySize];
                   String [] taskDevDetails = new String [arraySize];
                   String[] taskStatus = new String [arraySize];
                   String [] taskID = new String [arraySize];
                   int [] taskNumber = new int [arraySize];
                   int [] taskDuration = new int [arraySize];
                   
                   // make variables
                   int taskStatusNumber;
                   int totalHours = 0;
                   String displayReport;
                   
                   //make a object of the class
                   Tasks ts = new Tasks();
                   
                   //make a for loop
                   for (int i =0; i < arraySize; i++) {//loop starts here
                       taskNumber[i] = (i + 1);
                       taskName[i] = JOptionPane.showInputDialog(null,"Enter a task name for the task" + taskNumber[i]);
                       ts.checkTaskDescription = false;
                       
                       
                       while(ts.checkTaskDescription = false) {//while starts here
                           taskDescription[i]= JOptionPane.showInputDialog(null,"Enter a task description");
                           
                        //for unit testing
                        System.out.println(ts.ischeckTaskDescription(taskDescription[i]));
                       }//while ends here
                       
                       taskDevDetails[i] = JOptionPane.showInputDialog(null,"Enter a name and surname for developer");
                       taskDuration[i] = Integer.parseInt (JOptionPane.showInputDialog(null,"Enter task Duration"));
                       
                       
                       //request user to choose : do, doing, done
                       taskStatusNumber = Integer.parseInt(JOptionPane.showInputDialog(null,"Please choose an option >>>"
                               + "\n[1] - To Do"
                               + "\n[2] - Done"
                               + "\n[3] - Doing"));
                       
                       //make switch
                       switch(taskStatusNumber) {//switch starts here
                           case 1: taskStatus[i]="To Do";break;
                           case 2: taskStatus[i]="Done";break;
                           case 3: taskStatus[i]="Doing";break;
                       }//switch ends here
                           
                        taskID[i] = ts.getCreateTaskID(taskName[i],Integer.toString(taskNumber[i]), taskDevDetails[i],Integer.parseInt(taskID[i]));
                        
                        //pull unit tests in printline
                        totalHours = ts.getreturnTotalHours (taskDuration[i],totalHours); 
                        
                        //output total hours
                        if (arraySize > 0) {//starts here
                            JOptionPane.showMessageDialog(null,"Total Hours: " + totalHours);
                        }//if ends here  
                        }//loop ends here
                   
                        //display report
                        displayReport = ts.printTaskDetails;
                   }//method ends here}
                   
                       
                      
                    }
               
                   
               
                   
              
                   
           
     
        
    
    

