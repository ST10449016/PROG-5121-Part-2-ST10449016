/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finaltask2;

import javax.swing.JOptionPane;

/**
 *
 * @author preshay
 */
public class LoginPart2 {
       //create login method
    public static void loginUser(){//method starts here
        
        //make variables
        String checkUsername;
        String checkPassword;
        
        //get login details to check if the correct password and username is entered
        checkUsername = JOptionPane.showInputDialog(null,"Please enter your registered username here");
        checkPassword = JOptionPane.showInputDialog(null,"Please enter your registered password here");
        
        //if statement
        if(checkUsername.equals(RegisterPart2.registeredUsername)&& checkPassword.equals(RegisterPart2.registeredPassword)){
            JOptionPane.showMessageDialog(null,"\n Congratulations "+ RegisterPart2.regname + " "+ RegisterPart2.regsurname+
                    " you have successfully logged in! \n");
        }
        else{
            JOptionPane.showMessageDialog(null,"Username or pssword incorrect! \n"
                        + "Please try again");
        }    
    }//method ends here
}
